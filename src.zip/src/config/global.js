/**
 * Created by Administrator on 2017/5/2.
 */
    global = window ;
global.REMOTE_PROXY ='https://bird.ioliu.cn/v1/?url='
global.NEXT="NEXT"
global.PRE="PRE";
global.CURRENT="CURRENT";
global.DISTANCEBTM=100;